import psycopg2
import sys

con = None

try:
    con = psycopg2.connect("host='localhost' dbname='testdb' user='pythonspot' password='password'")
    cur = con.cursor()
    cur.execute("CREATE TABLE Products(Id INTEGER PRIMARY KEY, Name VARCHAR(20), Price INT)")
    cur.execute("INSERT INTO Products VALUES(1,'User',15)")
    cur.execute("INSERT INTO Products VALUES(2,'Pass',17)")
    cur.execute("INSERT INTO Products VALUES(3,'Data1',13)")
    cur.execute("INSERT INTO Products VALUES(4,'Data2',15)")
    cur.execute("INSERT INTO Products VALUES(5,'Data3',13)")
    cur.execute("INSERT INTO Products VALUES(6,'Data4',13)")
    cur.execute("INSERT INTO Products VALUES(7,'Data5',13)")
    cur.execute("INSERT INTO Products VALUES(8,'Data6',13)")
    con.commit()
except psycopg2.DatabaseError, e:
    if con:
        con.rollback()

    print
    'Error %s' % e
    sys.exit(1)

finally:
    if con:
        con.close()